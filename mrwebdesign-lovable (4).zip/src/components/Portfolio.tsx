import React, { useState } from 'react';
import { ArrowUpRight, Sparkles } from 'lucide-react';
import { PORTFOLIO_PROJECTS, createWhatsAppUrl } from '../data/portfolioData';
import { PortfolioProject } from '../types';
import { ProjectModal } from './ProjectModal';

export const Portfolio: React.FC = () => {
  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [selectedProject, setSelectedProject] = useState<PortfolioProject | null>(null);

  const categories = [
    { id: 'all', label: 'Todos os Projetos' },
    { id: 'ecommerce', label: 'E-commerce & Lojas' },
    { id: 'clinica', label: 'Saúde & Estética' },
    { id: 'b2b', label: 'Corporativo & B2B' },
  ];

  const filteredProjects = PORTFOLIO_PROJECTS.filter((proj) => {
    if (activeCategory === 'all') return true;
    if (activeCategory === 'ecommerce') return proj.category.toLowerCase().includes('commerce');
    if (activeCategory === 'clinica') return proj.category.toLowerCase().includes('saúde') || proj.category.toLowerCase().includes('estética');
    if (activeCategory === 'b2b') return proj.category.toLowerCase().includes('b2b') || proj.category.toLowerCase().includes('institucional');
    return true;
  });

  return (
    <section id="portfolio" className="py-20 md:py-32 bg-[#0E0E0E] relative border-t border-white/[0.06]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-6">
          <div className="max-w-2xl">
            <p className="text-xs uppercase tracking-widest text-[#D4AF37] font-semibold mb-3">
              Casos Reais & Portfólio Selecionado
            </p>
            <h2 className="font-serif-luxury text-3xl sm:text-4xl lg:text-5xl font-bold text-white tracking-tight leading-tight">
              Projetos Que Geram Faturamento
            </h2>
            <div className="w-16 h-[2px] bg-[#D4AF37] mt-5 mb-4" />
            <p className="text-base text-neutral-300">
              Cada site é arquitetado com um único objetivo: elevar a percepção de valor do negócio e transformar visitantes em clientes pagantes.
            </p>
          </div>

          {/* Interactive Category Tabs */}
          <div className="flex flex-wrap items-center gap-2 p-1 bg-[#161616] border border-white/[0.08] rounded-xl shrink-0">
            {categories.map((cat) => (
              <button
                key={cat.id}
                onClick={() => setActiveCategory(cat.id)}
                className={`px-3.5 py-2 text-xs font-medium rounded-lg transition-all duration-200 whitespace-nowrap shrink-0 ${
                  activeCategory === cat.id
                    ? 'bg-[#D4AF37] text-black font-semibold shadow-sm'
                    : 'text-neutral-400 hover:text-white hover:bg-white/[0.04]'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>
        </div>

        {/* Project Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 sm:gap-8 items-stretch">
          {filteredProjects.map((project) => {
            return (
              <div
                key={project.id}
                className="group rounded-2xl bg-[#121212] border border-white/[0.08] hover:border-[#D4AF37]/50 p-6 sm:p-7 transition-all duration-300 flex flex-col justify-between hover:bg-[#151515]"
              >
                <div>
                  {/* Category and Year */}
                  <div className="flex items-center justify-between text-xs text-neutral-400 mb-3">
                    <span className="text-[#D4AF37] font-semibold uppercase tracking-wider text-[11px]">
                      {project.category}
                    </span>
                    <span className="font-mono text-neutral-500">{project.year}</span>
                  </div>

                  {/* Impact Highlight Badge */}
                  <div className="mb-4 p-3 rounded-lg bg-[#0A0A0A] border border-[#D4AF37]/30">
                    <span className="text-[10px] text-neutral-400 uppercase tracking-wider block font-medium">
                      Resultado Comprovado:
                    </span>
                    <span className="text-sm font-bold text-[#D4AF37]">
                      {project.impact}
                    </span>
                  </div>

                  <h3 
                    onClick={() => setSelectedProject(project)}
                    className="font-serif-luxury text-xl sm:text-2xl font-bold text-white group-hover:text-[#D4AF37] transition-colors cursor-pointer mb-3"
                  >
                    {project.title}
                  </h3>

                  <p className="text-xs sm:text-sm text-neutral-300 leading-relaxed mb-5">
                    {project.description}
                  </p>

                  {/* Deliverables tags */}
                  <div className="flex flex-wrap gap-1.5 mb-6">
                    {project.deliverables.slice(0, 3).map((item, dIdx) => (
                      <span key={dIdx} className="text-[11px] px-2.5 py-1 rounded-md bg-white/[0.04] text-neutral-300 border border-white/[0.06]">
                        {item}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Footer actions */}
                <div className="pt-4 border-t border-white/[0.06] flex items-center justify-between">
                  <button
                    onClick={() => setSelectedProject(project)}
                    className="text-xs font-semibold uppercase tracking-wider text-[#D4AF37] hover:text-[#E5C365] transition-colors inline-flex items-center gap-1.5 cursor-pointer"
                  >
                    <span>Ver Estudo de Caso</span>
                    <ArrowUpRight className="w-3.5 h-3.5" />
                  </button>

                  <a
                    href={createWhatsAppUrl(`Olá, Mariany! Vi o case do ${project.title} no portfólio e gostaria de um site semelhante para minha empresa.`)}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-xs text-neutral-400 hover:text-white transition-colors"
                    title="Solicitar projeto similar"
                  >
                    Pedir similar &rarr;
                  </a>
                </div>

              </div>
            );
          })}
        </div>

        {/* Global CTA Strip */}
        <div className="mt-16 text-center">
          <p className="text-sm text-neutral-400 mb-4">
            Cada negócio possui uma identidade exclusiva. Vamos desenhar a sua?
          </p>
          <a
            href={createWhatsAppUrl("Olá, Mariany! Gostaria de conversar sobre um projeto sob medida para minha empresa e solicitar um orçamento.")}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center justify-center gap-2 px-8 py-4 text-xs font-semibold uppercase tracking-wider text-black bg-[#D4AF37] hover:bg-[#E5C365] rounded-lg transition-all duration-300 shadow-[0_0_25px_rgba(212,175,55,0.25)] hover:shadow-[0_0_35px_rgba(212,175,55,0.45)] active:scale-95"
          >
            <Sparkles className="w-4 h-4" />
            <span>Solicitar Orçamento Personalizado no WhatsApp</span>
            <ArrowUpRight className="w-4 h-4" />
          </a>
        </div>

      </div>

      {/* Modal */}
      <ProjectModal 
        project={selectedProject} 
        onClose={() => setSelectedProject(null)} 
      />
    </section>
  );
};
